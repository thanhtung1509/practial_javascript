export default class ExampleController {
	constructor() {
		this.controllerName = 'Example Controller';
	}
}